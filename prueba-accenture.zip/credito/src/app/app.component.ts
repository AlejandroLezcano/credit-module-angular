import { Component, Input } from '@angular/core';
import swal from 'sweetalert'
declare var $:any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


//http://jasonwatmore.com/post/2018/05/10/angular-6-reactive-forms-validation-example

  export class AppComponent {
    title = 'app';
    register:any;
    currentTab:number = 0;

    ngOnInit(){
      this.showTab(this.currentTab);

    }

    showTab(n:number) {
      let x = document.getElementsByClassName("tab");
      $(x[n]).css("display","block");
      if (n == 0) {
        $("#prevBtn").css("display","none");
      } else {
        $("#prevBtn").css("display","inline");
      }

      this.fixStepIndicator(n)
    }

    nextPrev($rps){
      if($rps.status){
        this.register = $rps;
        let x = document.getElementsByClassName("tab");
        $(x[this.currentTab]).css("display","none");
        this.currentTab = this.currentTab + 1;
        if (this.currentTab >= x.length) {
          return false;
        }
        this.showTab(this.currentTab);
      }else{
        swal("Ocurrio un error!", $rps.message, "error");
      }

    }

    fixStepIndicator(n) {
      // This function removes the "active" class of all steps...
      let i, x = document.getElementsByClassName("step");
      for (i = 0; i < x.length; i++) {
        x[i].className = x[i].className.replace(" active", "");
      }
      //... and adds the "active" class on the current step:
      x[n].className += " active";
    }

  }
