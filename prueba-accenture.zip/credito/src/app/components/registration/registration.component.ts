import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegisterService } from '../../services/register/register.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registerForm: FormGroup;
  @Output() statusRegister = new EventEmitter();
  constructor(private formBuilder: FormBuilder, private serviceRegister: RegisterService) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      Name: ['', Validators.required],
      birthdate: ['', Validators.required],
      IdentificationDocument: ['', [Validators.required]]
    });
  }

  validRegister() {
    if (this.registerForm.valid) {
      if(this.validateAge(this.registerForm.controls.birthdate.value) == false){
        this.statusRegister.emit({status:false,message:"Debes ser mayor de edad."});
      }else{
          this.serviceRegister.getRegister(this.registerForm.controls.IdentificationDocument.value).subscribe(resp =>{
          if(resp.recordset != undefined && resp.recordset.length > 0){
            this.statusRegister.emit({status:false,message:"El numero de documento que acabas de ingresar ya se encuentra registrado."});
          }else{
              this.statusRegister.emit({
                status:true,message:"",
                numDoc:this.registerForm.controls.IdentificationDocument.value,
                name:this.registerForm.controls.Name.value,
                birthDate :this.registerForm.controls.birthdate.value,
              });
          }
        });
      }
    }else{
      let message = "";
      let controls = this.registerForm.controls;
      console.log(controls);
      if(controls.IdentificationDocument.errors){
        if(controls.IdentificationDocument.errors.required){
          message = "Debes ingresar un numero de documento";
          this.statusRegister.emit({status:false,message:message});
        }
      }else if(controls.Name.errors){
        if(controls.Name.errors.required){
          message = "Debes ingresar tu nombre";
          this.statusRegister.emit({status:false,message:message});
        }
      }else if(controls.birthdate.errors){
        if(controls.birthdate.errors.required){
          message = "Debes ingresar tu fecha de nacimiento";
          this.statusRegister.emit({status:false,message:message});
        }

      }
    }
  }

  validateAge($age:string):boolean{
    let d = new Date();
    let month = d.getMonth();
    month = month + 1;
    let year = d.getFullYear() - 18;
    let dateFull = year + '-' + month + '-' + d.getDate();
    if(parseInt(dateFull) < parseInt($age)){
      return false;
    }else{
      return true;
    }
  }

}
