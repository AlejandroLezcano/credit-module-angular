import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CreditService } from '../../services/credit/credit.service';

@Component({
  selector: 'app-credit',
  templateUrl: './credit.component.html'
})
export class CreditComponent implements OnInit {
  creditForm:FormGroup;
  approved:any;
  @Input() client:any;
  @Output() statusCredit = new EventEmitter();
  constructor(private formBuilder: FormBuilder, private serviceCredit: CreditService ) { }
  ngOnInit(){
    this.creditForm = this.formBuilder.group({
      NameCompany: ['', Validators.required],
      NITCompany: ['', Validators.required],
      salaryNumber: ['', [Validators.required, Validators.maxLength(8)] ],
      admissionDate: ['', Validators.required]
    });
  }
  validCredit(){
      console.log(this.client);
    if (this.creditForm.valid){
        if (this.validateAdmission(this.creditForm.controls.admissionDate.value) == false) {
              this.statusCredit.emit({status:false,message:"Debes llevar mas de un año y medio laborando en la empresa"});
        }else{
          let  returnSalary = this.ValidateSalary(this.creditForm.controls.salaryNumber.value);
          if ( returnSalary.status ) {
            let register:any = {};
            let controls = this.creditForm.controls;
            register.document = String(this.client.numDoc);
            register.nameCompany = controls.NameCompany.value;
            register.nitCompany = String(controls.NITCompany.value);
            register.salary = String(controls.salaryNumber.value);
            register.dateLog = controls.admissionDate.value;
            this.serviceCredit.addRegister(register).subscribe(resp =>{
              let id = Math.floor(Math.random() * (900 - 1)) + 1;
              this.serviceCredit.add({
                    idCredit:id,
                    docClient:register.document,
                    amount:this.approved
                  }).subscribe($rps => {
                    swal("Señor(a) " + this.client.name, returnSalary.message, "success");
                });

            });

          }else{
              this.statusCredit.emit({status:false,message: returnSalary.message });
          }
        }
    }else{
      let message = "";
      let controls = this.creditForm.controls;

      if (controls.NameCompany.errors) {
          if (controls.NameCompany.errors.required) {
              message = "Debes ingresar el nombre de tu empresa";
              this.statusCredit.emit({status:false,message:message});

          }
      }else if(controls.NITCompany.errors) {
          if (controls.NITCompany.errors.required) {
              message = "Debes ingresar el NIT de tu empresa";
              this.statusCredit.emit({status:false,message:message});
          }
      }else if(controls.salaryNumber.errors){
          if (controls.salaryNumber.errors.required) {
              message = "Debes ingresar tu salario actual";
              this.statusCredit.emit({status:false,message:message});
          }
      }else if (controls.admissionDate.errors){
          if (controls.admissionDate.errors.required) {
              message = "Debes ingresar tu fecha de admision en la empresa";
              this.statusCredit.emit({status:false,message:message});
          }
      }
    }
  }

  validateAdmission($admission:string):boolean{
    let d = new Date();
    let month = d.getMonth() - 6;
    month = month + 1;
    let year = d.getFullYear() - 1;
    let dateFull = year + '-' + month + '-' + d.getDate();
    if (parseInt(dateFull) < parseInt($admission)){
        return false;
    }else{
      return true;
    }
  }

  ValidateSalary($salary:number){
    if ($salary > 800000) {
        if ($salary <= 1000000) {
          this.approved = "5000000"
          return { status:true,message:" Para nosotros es un gusto informarle que su credito ha sido aprobado por un valor de $5.000.000"};
        }
        else if ($salary > 1000000 && $salary <= 4000000) {
          this.approved = "20000000"
          return { status:true,message:"  Para nosotros es un gusto informarle que su credito ha sido aprobado por un valor de $20.000.000"};
        }
        else if ($salary > 4000000 && $salary < 100000000) {
          this.approved = "50000000"
          return { status:true,message:" Para nosotros es un gusto informarle que su credito ha sido aprobado por un valor de $50.000.000"};
        }else{
          return { status:false,message:" Para poder solicitar el credito su salario no debe ser mayor a $100.000.000"};
        }
    }else{
      return { status:false,message:" Para poder solicitar el credito su salario debe ser mayor a $800.000"};
    }

  }


}
